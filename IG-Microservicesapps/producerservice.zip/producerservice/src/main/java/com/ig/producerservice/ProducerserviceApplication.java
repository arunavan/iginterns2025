package com.ig.producerservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProducerserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProducerserviceApplication.class, args);
	}

}
