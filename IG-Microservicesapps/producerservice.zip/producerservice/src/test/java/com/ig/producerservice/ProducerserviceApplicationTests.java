package com.ig.producerservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProducerserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
