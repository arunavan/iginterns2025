package com.infy.service;

import java.util.List;

import com.infy.dto.CustomerDTO;
import com.infy.exception.CustomerException;



public interface CustomerService {
	public Integer addCustomer(CustomerDTO customerDTO) throws CustomerException;
	public CustomerDTO getCustomer(Integer customerId) throws CustomerException;
	public void updateCustomer(Integer customerId, String emailId)throws CustomerException;
	public void deleteCustomer(Integer customerId)throws CustomerException;
	public List<CustomerDTO> getAllCustomers() throws CustomerException;
}
