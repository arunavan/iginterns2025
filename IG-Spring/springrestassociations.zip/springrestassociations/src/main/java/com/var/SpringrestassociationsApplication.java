package com.var;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringrestassociationsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringrestassociationsApplication.class, args);
	}

}
//http://localhost:8080/swagger-ui/index.html
