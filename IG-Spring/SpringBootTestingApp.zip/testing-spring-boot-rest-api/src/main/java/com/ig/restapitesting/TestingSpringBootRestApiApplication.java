package com.ig.restapitesting;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestingSpringBootRestApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestingSpringBootRestApiApplication.class, args);
	}

}
