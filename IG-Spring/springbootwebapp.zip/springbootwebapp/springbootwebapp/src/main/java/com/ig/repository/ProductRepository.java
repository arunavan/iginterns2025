package com.ig.repository;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.ig.model.Product;

@Repository
public class ProductRepository {
   
	static ArrayList<Product> productList=new ArrayList<>();
    
	
	
    public  void addPRoduct(Product product) {
    	
    	productList.add(product);
    }
    public  Product getPRoduct(Integer id1) {
    	
    	Product p=new Product();
    	for( Product p1 :productList)
    	{
    		if( p1.id==id1) {
    			p.setId(p1.getId());
    			p.setName(p1.getName());
    			p.setPrice(p1.getPrice());
    		}
    	}
    	return p;
    }
    
public  List<Product> getAllProduct() {
    	return productList;
    	
    }
  public  Product updatePRoduct(Integer id1,Product product) {
    	Product pp=new Product();
    	
    	for( Product p1 :productList)
    	{
    		if( p1.id==id1) {
    			p1.setPrice(product.getPrice());
    		}
    		
    		pp.setId(p1.id);
    		pp.setName(p1.getName());
    		pp.setPrice(p1.getPrice());
    	}
    	return pp;
    }
    
  public  String  deletePRoduct(Integer id1) {
  	productList.removeIf(x->x.getId()==id1);
  	
  	
  	/*Collections.synchronizedList(productList);
  	for( Product p1 :productList)
  	{
  		if( p1.id==id1) {
  			productList.remove(p1);
  		}
  		
  	
  }*/
    return "delete success";
    
    
}
  
}
