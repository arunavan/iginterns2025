package com.ig.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.ig.model.Product;
import com.ig.service.ProductService;

@RestController
public class ProductController {
	
	@Autowired
	ProductService productService;
	
	
	 @PostMapping("/add")
	 public String  addProduct(@RequestBody Product product) {
		 productService.addProduct(product);
		 
		  return "add product is succes";
	 }
	 @PutMapping("/update/{id}")
	 public Product  updateProduct(@PathVariable("id") Integer id,@RequestBody Product product) {
		 return  productService.updateProduct(id, product);
		  //return "update product is succes";
	 }
	 
	 @GetMapping("/read/{id}")
	 public Product  getProduct(@PathVariable("id") Integer id) {
		return  productService.getProduct(id);
		  //return "read product is succes";
	 }
	 @GetMapping("/readall")
	 public List<Product>  getProducts() {
		 return productService.getAllProduct();
		//  return "read product is succes";
	 }
	 @DeleteMapping("/delete/{id}")
	 public String  deleteProduct(@PathVariable("id") Integer id) {
		  return productService.deleteProduct(id);
	 }
}
