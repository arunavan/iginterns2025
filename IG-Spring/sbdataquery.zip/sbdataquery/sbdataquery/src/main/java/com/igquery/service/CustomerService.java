package com.igquery.service;

import java.time.LocalDate;
import java.util.List;

import com.igquery.dto.CustomerDTO;
import com.igquery.exception.CustomerException;




public interface CustomerService {
	String findNameByEmailId(String emailId);
	void updateCustomerEmailId(String newEmailId, Integer customerId) throws CustomerException;
	void deleteCustomerByEmailId(String emailId) throws CustomerException;
}


/*
public interface CustomerService {

	public CustomerDTO findByEmailId(String emailId) throws CustomerException;

	public CustomerDTO findByEmailIdAndName(String emailId, String name) throws CustomerException;

	public List<CustomerDTO> findByEmailIdOrName(String emailId, String name) throws CustomerException;

	public List<CustomerDTO> findByDateOfBirthBetween(LocalDate fromDate, LocalDate toDate) throws CustomerException;

	public List<CustomerDTO> findByDateOfBirthLessThan(LocalDate dateOfBirth) throws CustomerException;

	public List<CustomerDTO> findByDateOfBirthGreaterThan(LocalDate dateOfBirth) throws CustomerException;

	public List<CustomerDTO> findByDateOfBirthAfter(LocalDate dateOfBirth) throws CustomerException;

	public List<CustomerDTO> findByDateOfBirthBefore(LocalDate dateOfBirth) throws CustomerException;

	public List<CustomerDTO> findByEmailIdNull() throws CustomerException;

	public List<CustomerDTO> findByNameLike(String pattern) throws CustomerException;

	public List<CustomerDTO> findByNameOrderByDateOfBirth(String name) throws CustomerException;

	public List<CustomerDTO> findByNameOrderByDateOfBirthDesc(String name) throws CustomerException;
}

*/
