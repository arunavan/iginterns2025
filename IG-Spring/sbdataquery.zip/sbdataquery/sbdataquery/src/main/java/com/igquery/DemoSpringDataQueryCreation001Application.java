package com.igquery;

import java.time.LocalDate;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.core.env.Environment;

import com.igquery.dto.CustomerDTO;
import com.igquery.service.CustomerServiceImpl;



@SpringBootApplication
public class DemoSpringDataQueryCreation001Application   implements CommandLineRunner {
	
	private static final Log LOGGER = LogFactory.getLog(DemoSpringDataQueryCreation001Application.class);
	
	@Autowired
	CustomerServiceImpl customerService;

	
	

	public static void main(String[] args) {
		SpringApplication.run(DemoSpringDataQueryCreation001Application.class, args);

	}

	public void run(String... args) throws Exception {
		
		/* findByEmailId();
		 findByEmailIdAndName();
		 findByEmailIdOrName();
		 findByDateOfBirthBetween();
		 findByDateOfBirthLessThan();
		 findByDateOfBirthGreaterThan();
		 findByDateOfBirthAfter();
		 findByDateOfBirthBefore();
		 findByEmailIdIsNull();
		 findByNameLike();
		 findByNameOrderByDateOfBirth();
		 findByNameOrderByDateOfBirthDesc();
		 */

			//findNameByEmailId();
			//updateCustomerByEmailId();
			deleteCustomerByEmailId();

		}

		public void findNameByEmailId() {
			try {
				String name = customerService.findNameByEmailId("ram@gmail.com");

				LOGGER.info("Customer name : " + name);

			} catch (Exception e) {

				if (e.getMessage() != null)
					LOGGER.info("Something went wrong");
			}
		}

		public void updateCustomerByEmailId() {

			try {
				customerService.updateCustomerEmailId("ram@gmail.com", 3);
				LOGGER.info("UPDATE_SUCCESS");
			} catch (Exception e) {

				if (e.getMessage() != null)
					LOGGER.info("Something went wrong");			}
		}

		public void deleteCustomerByEmailId() {

			try {
				customerService.deleteCustomerByEmailId("ram@gmail.com");
				LOGGER.info("DELETE_SUCCESS");

			} catch (Exception e) {

				if (e.getMessage() != null)
					LOGGER.info("Something went wrong");
			}
		//}
	//}

		
		
	}
}
/*
		
		 
	

	public void findByEmailId() {

		try {

			CustomerDTO customerDTO = customerService.findByEmailId("ram@gmail.com");
			LOGGER.info(customerDTO);
			LOGGER.info("\n");
		} catch (Exception e) {

			if (e.getMessage() != null)
				LOGGER.info("Something went wrong");
		}

	}

	public void findByEmailIdAndName() {

		try {

			CustomerDTO customerDTO = customerService.findByEmailIdAndName("martin@infy.com", "martin");

			LOGGER.info(customerDTO);LOGGER.info("\n");
		} catch (Exception e) {

			if (e.getMessage() != null)
				LOGGER.info("Something went wrong");
		}

	}

	public void findByEmailIdOrName() {

		try {

			List<CustomerDTO> customerDTOs = customerService.findByEmailIdOrName("martin@infy.com", "martin");

			customerDTOs.forEach(customerDTO -> {
				LOGGER.info(customerDTO);
			});LOGGER.info("\n");
		} catch (Exception e) {

			if (e.getMessage() != null)
				LOGGER.info("Something went wrong");
		}

	}

	public void findByDateOfBirthBetween() {
		try {
			LocalDate fromDate = LocalDate.of(1995, 1, 1);
			LocalDate toDate = LocalDate.of(2000, 12, 31);

			List<CustomerDTO> customerDTOs = customerService.findByDateOfBirthBetween(fromDate, toDate);

			customerDTOs.forEach(customerDTO -> {
				LOGGER.info(customerDTO);
			});LOGGER.info("\n");
		} catch (Exception e) {

			if (e.getMessage() != null)
				LOGGER.info(
						"Something went wrong");
		}
	}

	public void findByDateOfBirthLessThan() {
		try {

			LocalDate dateOfBirth = LocalDate.of(2000, 12, 31);

			List<CustomerDTO> customerDTOs = customerService.findByDateOfBirthLessThan(dateOfBirth);

			customerDTOs.forEach(customerDTO -> {
				LOGGER.info(customerDTO);
			});LOGGER.info("\n");
		} catch (Exception e) {

			if (e.getMessage() != null)
				LOGGER.info(
						"Something went wrong");	}
	}

	public void findByDateOfBirthGreaterThan() {
		try {

			LocalDate dateOfBirth = LocalDate.of(1995, 12, 31);

			List<CustomerDTO> customerDTOs = customerService.findByDateOfBirthGreaterThan(dateOfBirth);

			customerDTOs.forEach(customerDTO -> {
				LOGGER.info(customerDTO);
			});LOGGER.info("\n");
		} catch (Exception e) {

			if (e.getMessage() != null)
				LOGGER.info(
						"Something went wrong");	}
	}

	public void findByDateOfBirthAfter() {
		try {

			LocalDate dateOfBirth = LocalDate.of(1995, 12, 31);

			List<CustomerDTO> customerDTOs = customerService.findByDateOfBirthAfter(dateOfBirth);

			customerDTOs.forEach(customerDTO -> {
				LOGGER.info(customerDTO);
			});LOGGER.info("\n");
		} catch (Exception e) {

			if (e.getMessage() != null)
				LOGGER.info(
						"Something went wrong");	}
	}

	public void findByDateOfBirthBefore() {
		try {

			LocalDate dateOfBirth = LocalDate.of(2000, 12, 31);

			List<CustomerDTO> customerDTOs = customerService.findByDateOfBirthBefore(dateOfBirth);

			customerDTOs.forEach(customerDTO -> {
				LOGGER.info(customerDTO);
			});LOGGER.info("\n");
		} catch (Exception e) {

			if (e.getMessage() != null)
				LOGGER.info(
						"Something went wrong");	}
	}

	public void findByEmailIdIsNull() {
		try {

			List<CustomerDTO> customerDTOs = customerService.findByEmailIdNull();

			customerDTOs.forEach(customerDTO -> {
				LOGGER.info(customerDTO);
			});LOGGER.info("\n");
		} catch (Exception e) {

			if (e.getMessage() != null)
				LOGGER.info(
						"Something went wrong");	}
	}

	public void findByNameLike() {
		try {

			List<CustomerDTO> customerDTOs = customerService.findByNameLike("j%");

			customerDTOs.forEach(customerDTO -> {
				LOGGER.info(customerDTO);
			});LOGGER.info("\n");
		} catch (Exception e) {

			if (e.getMessage() != null)
				LOGGER.info("Something went wrong");
		}
	}

	public void findByNameOrderByDateOfBirth() {
		try {
			List<CustomerDTO> customerDTOs = customerService.findByNameOrderByDateOfBirth("martin");

			customerDTOs.forEach(customerDTO -> {
				LOGGER.info(customerDTO);
			});LOGGER.info("\n");
		} catch (Exception e) {

			if (e.getMessage() != null)
				LOGGER.info(
						"Something went wrong");
		}
	}

	void findByNameOrderByDateOfBirthDesc() {
		try {
			List<CustomerDTO> customerDTOs = customerService.findByNameOrderByDateOfBirthDesc("martin");

			customerDTOs.forEach(customerDTO -> {
				LOGGER.info(customerDTO);
			});LOGGER.info("\n");
		} catch (Exception e) {

			if (e.getMessage() != null)
				LOGGER.info("Something went wrong");
		}
	}
  
		

}
/*

insert into customer (customer_id,date_of_birth,email_id,name) values(2,'1999-02-02','raj@gmail.com','raj');
insert into customer (customer_id,date_of_birth,email_id,name) values(3,'1999-02-02','ram@gmail.com','ram');

*/