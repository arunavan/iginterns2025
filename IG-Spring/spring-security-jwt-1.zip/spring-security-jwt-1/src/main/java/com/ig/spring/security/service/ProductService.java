package com.ig.spring.security.service;

import java.util.List;

import com.ig.spring.security.dto.Product;
import com.ig.spring.security.entity.UserInfo;

public interface ProductService {
	public void loadProductsFromDB();
	public List<Product> getAllProducts();
	public Product getProductById(int id);
	
	public String addUser(UserInfo userInfo);
}