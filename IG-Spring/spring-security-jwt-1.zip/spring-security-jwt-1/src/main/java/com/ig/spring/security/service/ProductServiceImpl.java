package com.ig.spring.security.service;

import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.factory.PasswordEncoderFactories;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.ig.spring.security.dto.Product;
import com.ig.spring.security.entity.UserInfo;
import com.ig.spring.security.repository.UserInfoRepository;

import jakarta.annotation.PostConstruct;

@Service(value = "productService")
public class ProductServiceImpl implements ProductService{
	@Autowired
	private UserInfoRepository userInfoRepository;
	
	private List<Product> productList;

	@PostConstruct
	public void loadProductsFromDB() {
		productList = IntStream.rangeClosed(1, 100)
				.mapToObj(i-> Product.builder()
						.productId(i)
						.name("product: "+i)
						.quantity(new Random().nextInt(10))
						.price(new Random().nextDouble(5000)).build()


						).collect(Collectors.toList());

	}
	
	public List<Product> getAllProducts() {
		return productList;
	}
	
	
	public Product getProductById(int id) {
		try {
			return productList.stream().filter(p->p.getProductId()==id)
					.findAny().orElseThrow(()->new Exception("Product Id Invalid"));
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public String addUser(UserInfo userInfo) {
		PasswordEncoder encoder = PasswordEncoderFactories.createDelegatingPasswordEncoder();
		userInfo.setPassword(encoder.encode(userInfo.getPassword()));
		userInfo.setRoles("ROLE"+"_"+ userInfo.getRoles());
		userInfoRepository.save(userInfo);
		return "user added to database";
	}
}
