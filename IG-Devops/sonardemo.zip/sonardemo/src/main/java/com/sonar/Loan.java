package com.sonar;

public class Loan {

	public Loan() {
		// TODO Auto-generated constructor stub
	}
	
	public int getEmi() {
		int x=10;
		return 99;
	}

}
