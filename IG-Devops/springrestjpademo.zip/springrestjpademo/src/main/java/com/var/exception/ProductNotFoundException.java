package com.var.exception;

public class ProductNotFoundException extends Exception {

	public ProductNotFoundException() {
		//super(msg);
	}

}
